<?php 

function chargerData() {
    $lines = file("films.txt");
    $tabFilm=array();
    foreach ($lines as $lineNumber => $lineContent){
        $tab = explode(";", $lineContent);
        $film = array();
        $film['id']=$tab[0];
        $film['nom']=$tab[1];
        $film['desc']=$tab[2];
        $film['image']=$tab[3];
        $tabFilm[]=$film;   
    }
    return $tabFilm;  
}

$tab = chargerData();
$result="";
foreach($tabResult as $personne) {
    $result.="<tr id=\"ligneid".$tab['id']."\"><td>".$tab['id']."</td>";
    $result.="<td>".$tab['nom']."</td>";
    $result.="<td>".$tab['desc']."</td>";
    $result.="<td><img src=\"".$tab['image']."\"></td></tr>";
}
echo($result);

?>